#
# Copyright (c) Citrix Systems, Inc.
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
#   1) Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
# 
#   2) Redistributions in binary form must reproduce the above
#      copyright notice, this list of conditions and the following
#      disclaimer in the documentation and/or other materials
#      provided with the distribution.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
# OF THE POSSIBILITY OF SUCH DAMAGE.
#

# Powershell Automated Tests

Param([Parameter(Mandatory=$true)][String]$out_xml,
       [Parameter(Mandatory=$true)][String]$svr,
       [Parameter(Mandatory=$true)][String]$usr,
       [Parameter(Mandatory=$true)][String]$pwd,
       [Parameter(Mandatory=$true)][String]$sr_svr,
       [Parameter(Mandatory=$true)][String]$sr_path)

# Initial Setup

[Net.ServicePointManager]::SecurityProtocol='tls,tls11,tls12'
$BestEffort = $false
$NoWarnCertificates = $true
$info = $true
$warn = $true
$err = $true
$prog = $false

$Eap = $ErrorActionPreference
$Vp = $VerbosePreference
$Wp = $WarningPreference
$Ep = $ErrorPreference

$ErrorActionPreference = "Stop"
$VerbosePreference="Continue"
$WarningPreference="Continue"
$ErrorPreference="Continue"
$ErrorVariable

# End Initial Setup

# Helper Functions

function log_info([String]$msg)
{
  process
  {
    if($info)
	{
	  write-verbose $msg
	}
  }
}

function log_warn([String]$msg)
{
  process
  {
    if($warn)
	{
      write-warning $msg
	}
  }
}

function log_error([String]$msg)
{
  process
  {
    if($err) 
	{
      write-error $msg
	}
  }
}

function escape_for_xml([String]$content)
{
  return $content.replace("&", "&amp;").replace("'", "&apos;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
}

function prep_xml_output([String]$out_file)
{
  $date = Get-Date
  "<results>" > $out_file
  ("<testrun>Test Run Info: PowerShell bindings test {0}</testrun>" -f $date) >> $out_file
  "<group>" >> $out_file
}

function close_xml_output([String]$out_file)
{
  "</group>" >> $out_file
  "</results>" >> $out_file
}

function add_result([String]$out_file,[String]$cmd, [String]$test_name, [Exception]$err)
{
  $out_cmd = escape_for_xml $cmd
  $out_test_name = escape_for_xml $test_name
  $out_err = escape_for_xml $err
  "<test>" >> $out_file
  ("<name>{0}</name>" -f $out_test_name) >> $out_file
  if (($err -ne $null))
  {
    "<state>Fail</state>" >> $out_file
	"<log>" >> $out_file
    ("Cmd: '{0}'" -f $out_cmd) >> $out_file
	("Exception: {0}" -f $out_err) >> $out_file
	"</log>" >> $out_file
  }
  else
  {
    "<state>Pass</state>" >> $out_file
    "<log />" >> $out_file
  }
  "</test>" >> $out_file
}


function exec([String]$test_name, [String]$cmd, [String]$expected)
{
  trap [Exception]
  {
     add_result $out_xml $cmd $test $_.Exception
	 $fails.Add($test_name, $_.Exception)
	 break
  }
  
  log_info ("Test '{0}' Started: cmd = {1}, expected = {2}" -f $test_name,$cmd,$expected)
  $result = Invoke-Expression $cmd
  if ($result -eq $expected)
  {
    add_result $out_xml $cmd $test_name $null
	return $true
  }
  else
  {
    $exc = new-object Exception("Test '{0}' Failed: expected '{1}'; actual '{2}'" `
                                -f $test_name,$expected,$result)
    add_result $out_xml $cmd $test_name $exc
	$fails.Add($test_name, $exc)
	return $false
  }
}

# End Helper Functions

# Connect Functions

function connect_server([String]$svr, [String]$usr, [String]$pwd)
{
  log_info ("connecting to server '{0}'" -f $svr)
  $session = Connect-XenServer -Server $svr -UserName $usr -Password $pwd -PassThru

  if($session -eq $null)
  {
    return $false
  }
  return $true

}

function disconnect_server([String]$svr)
{
  log_info ("disconnecting from server '{0}'" -f $svr)
  Get-XenSession -Server $svr | Disconnect-XenServer

  if ((Get-XenSession -Server $svr) -eq $null)
  {
    return $true
  }
  return $false
}

# End Connect Functions

# VM Functions

function destroy_vm([XenAPI.VM]$vm)
{
  if ($vm -eq $null)
  {
    return
  }

  log_info ("destroying vm '{0}'" -f $vm.name_label)
  
  $vdis = @()
  
  foreach($vbd in $vm.VBDs)
  {
	if((Get-XenVBDProperty -Ref $vbd -XenProperty Mode) -eq [XenAPI.vbd_mode]::RW)
	{
      $vdis += Get-XenVBDProperty -Ref $vbd -XenProperty VDI
	}
  }
  
  Remove-XenVM -VM $vm -Async -PassThru | Wait-XenTask -ShowProgress
  
  foreach($vdi in $vdis)
  {
    Remove-XenVDI -VDI $vdi -Async -PassThru | Wait-XenTask -ShowProgress
  }
}

function install_vm([String]$name, [String]$sr_name)
{
  trap [Exception]
  {
  	trap [Exception]
	{
	  log_warn "Clean up after failed vm install unsuccessful"
	  log_info "...failed!"
	  break
	}

    log_info "Attempting to clean up after failed vm install..."

	$vms = Get-XenVM -Name $name

	foreach($vm in $vms)
  	{
  	  destroy_vm($vm)
  	}
	log_info "...success."
	break
  }

  #find a windows template
  log_info "looking for a Windows template..."
  $template = @(Get-XenVM -Name 'Windows *' | where {$_.is_a_template})[0]

  log_info ("installing vm '{0}' from template '{1}'" -f $template.name_label,$name)
  
  #clone template
  log_info ("cloning vm '{0}' to '{1}'" -f $template.name_label,$name)
  Invoke-XenVM -VM $template -XenAction Clone -NewName $name -Async `
                     -PassThru | Wait-XenTask -ShowProgress
  
  $vm = Get-XenVM -Name $name  
  $sr = Get-XenSR -Name $sr_name
  $other_config = $vm.other_config
  $other_config["disks"] = $other_config["disks"].Replace('sr=""', 'sr="{0}"' -f $sr.uuid)
  
  #add cd drive
  log_info ("creating cd drive for vm '{0}'" -f $vm.name_label)
  New-XenVBD -VM $vm -VDI $null -Userdevice 3 -Bootable $false -Mode RO `
             -Type CD -Unpluggable $true -Empty $true -OtherConfig @{} `
             -QosAlgorithmType "" -QosAlgorithmParams @{}

  Set-XenVM -VM $vm -OtherConfig $other_config
  
  #provision vm 
  log_info ("provisioning vm '{0}'" -f $vm.name_label)
  Invoke-XenVM -VM $vm -XenAction Provision -Async -PassThru | Wait-XenTask -ShowProgress
  
  return $true
}

function uninstall_vm([String]$name)
{
  log_info ("uninstalling vm '{0}'" -f $name)
   
  $vms = Get-XenVM -Name $name
  
  foreach($vm in $vms)
  {
    destroy_vm($vm)
  }
  
  return $true
}

function vm_can_boot($vm_name, [XenApi.Host[]] $servers)
{
  trap [Exception]
  {
    $script:exceptions += $_.Exception
	continue
  }

  $script:exceptions = @()
  foreach ($server in $servers)
  {
    Invoke-XenVM -Name $vm_name -XenAction AssertCanBootHere -XenHost $server
  }
  
  if ($exceptions.Length -lt $servers.Length)
  {
  	return $true
  }
  
  log_info "No suitable place to boot VM:"
  
  foreach ($excep in $script:exceptions)
  {
  	log_info ("Reason: {0}" -f $excep.Message)
  }

  return $false
}

function start_vm([String]$vm_name)
{
  if (vm_can_boot $vm_name @(Get-XenHost))
  {
  	log_info ("starting vm '{0}'" -f $vm_name)
  }

  # even if we cant start it, attempt so we get the exception, reasons have been logged in vm_can_boot
  Invoke-XenVM -Name $vm_name -XenAction Start -Async -PassThru | Wait-XenTask -ShowProgress
  return Get-XenVM -Name $vm_name | Get-XenVMProperty -XenProperty PowerState
}

function shutdown_vm([String]$vm_name)
{
  log_info ("shutting down vm '{0}'" -f $vm_name)
  Invoke-XenVM -Name $vm_name -XenAction HardShutdown -Async -PassThru | Wait-XenTask -ShowProgress
  return (Get-XenVM -Name $vm_name).power_state
}

# End VM Functions

# Host Functions

function get_master()
{
  $pool = Get-XenPool
  return Get-XenHost -Ref $pool.master
}

# End Host Functions

# SR Functions

function get_default_sr()
{
  log_info ("getting default sr")
  $pool = Get-XenPool
  return (Get-XenPool).default_SR | Get-XenSR 
}

function create_nfs_sr([String]$sr_svr, [String]$sr_path, [String]$sr_name)
{
  log_info ("creating sr {0} at {1}:{2}" -f $sr_name,$sr_svr,$sr_path)
  $master = get_master
  $sr_opq = New-XenSR -XenHost $master -DeviceConfig @{ "server"=$sr_svr; "serverpath"=$sr_path; "options"="" } `
                  -PhysicalSize 0 -NameLabel $sr_name -NameDescription "" -Type "nfs" -ContentType "" `
                  -Shared $true -SmConfig @{} -Async -PassThru `
        | Wait-XenTask -ShowProgress -PassThru

  if ($sr_opq -eq $null)
  {
    return $false
  }
  return $true
}

function detach_nfs_sr([String]$sr_name)
{
  log_info ("destroying sr {0}" -f $sr_name)

  $pbds = Get-XenPBD
  $sr_opq = (Get-XenSR -Name $sr_name).opaque_ref

  foreach($pbd in $pbds)
  {
    if(($pbd.SR.opaque_ref -eq $sr_opq) -and $pbd.currently_attached)
    {
      Invoke-XenPBD -PBD $pbd -XenAction Unplug
    }
  }
  
  $sr_opq = Remove-XenSR -Name $sr_name -Async -PassThru | Wait-XenTask -ShowProgress
 
  if ($sr_opq -eq $null)
  {
    return $true
  }
  return $false
}

# End SR Functions

# Helper Functions

function append_random_string_to([String]$toAppend, $length = 10)
{
	$randomisedString = $toAppend
	$charSet = "0123456789abcdefghijklmnopqrstuvwxyz".ToCharArray()
	for($i; $i -le $length; $i++)
	{
		$randomisedString += $charSet | Get-Random
	}
	return $randomisedString
}

# End Helper Functions

# Test List

$tests = @(
            @("Connect Server", "connect_server $svr $usr $pwd", $true),
			@("Create SR", "create_nfs_sr $sr_svr $sr_path PowerShellAutoTestSR", $true),
            @("Install VM", "install_vm PowerShellAutoTestVM PowerShellAutoTestSR", $true),
			@("Start VM", "start_vm PowerShellAutoTestVM", "Running"),
			@("Shutdown VM", "shutdown_vm PowerShellAutoTestVM", "Halted"),
			@("Uninstall VM", "uninstall_vm 'PowerShellAutoTestVM'", $true),
			@("Destroy SR", "detach_nfs_sr PowerShellAutoTestSR", $true),
            @("Disconnect Server", "disconnect_server $svr", $true)
          )
# End Test List

# Main Test Execution
$complete = 0;
$max = $tests.Count;

$fails = @{}

prep_xml_output $out_xml

$vmName = append_random_string_to "PowerShellAutoTestVM"
$srName = append_random_string_to "PowerShellAutoTestSR"

foreach($test in $tests)
{
  trap [Exception]
  {
    # we encountered an exception in running the test before it completed
	# its already been logged, so continue
	continue
  }
  $success = $false
  
  # Add randomness to the names of the test VM and SR to 
  # allow a parallel execution context
  $cmd = $test[1]
  $cmd = $cmd -replace "PowerShellAutoTestVM", $vmName
  $cmd = $cmd -replace "PowerShellAutoTestSR", $srName
  
  $success = exec $test[0] $cmd $test[2]
  if ($success)
  {
    $complete++
  }
}

close_xml_output $out_xml

$result = "Result: {0} completed out of {1}" -f $complete,$max;

write-host $result -f 2

if($fails.Count -gt 0)
{
  write-host "Failures:"
  $fails
}

$ErrorActionPreference = $Eap
$VerbosePreference = $Vp
$WarningPreference = $Wp
$ErrorPreference = $Ep

# End Main Test Execution

# SIG # Begin signature block
# MIIbXQYJKoZIhvcNAQcCoIIbTjCCG0oCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUpu6pI4Es822/rlob/2er2vH1
# w0igggpoMIIFBzCCA++gAwIBAgIQeLbNAXgCajiQz23Jx9C9sjANBgkqhkiG9w0B
# AQsFADB/MQswCQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRp
# b24xHzAdBgNVBAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxMDAuBgNVBAMTJ1N5
# bWFudGVjIENsYXNzIDMgU0hBMjU2IENvZGUgU2lnbmluZyBDQTAeFw0xNTEyMTAw
# MDAwMDBaFw0xNzAzMTAyMzU5NTlaMIGZMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# Q2FsaWZvcm5pYTEUMBIGA1UEBxMLU2FudGEgQ2xhcmExHTAbBgNVBAoUFENpdHJp
# eCBTeXN0ZW1zLCBJbmMuMSEwHwYDVQQLFBhYZW5TZXJ2ZXIoR2VuZXJhbFNIQTI1
# NikxHTAbBgNVBAMUFENpdHJpeCBTeXN0ZW1zLCBJbmMuMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEArqK/6dAIl1UfhgraNvCzflsGhyzVMpnlwNqS3e/h
# 7fI18CPp8FWoD2m7+VmBcUvK+sNVgasUHSkrVU95ExPt8vaTBzLSk+iz+yXvOqXU
# U5wQxBHoNOC2MYNZHK62nN3E8UC/LGBXlah5oDpmrM2kt14B5Oa88hxMxVI+vHui
# Adi4df/fKskjBLnC4iazj6v890/pAQy8CJ9Pw0iFVWBqarC/4I8dodJ5VsnYQ5vx
# G9XYy3wM3ATP40gGvDOFDRwzR0sdznR1QhouRsApXiGlLYlmmo1WZIfId/+YUm0b
# UN+V/DzuuArSRkqlfCyLFdFOfxV4jUvET+DAaak+6NBM7QIDAQABo4IBYjCCAV4w
# CQYDVR0TBAIwADAOBgNVHQ8BAf8EBAMCB4AwKwYDVR0fBCQwIjAgoB6gHIYaaHR0
# cDovL3N2LnN5bWNiLmNvbS9zdi5jcmwwZgYDVR0gBF8wXTBbBgtghkgBhvhFAQcX
# AzBMMCMGCCsGAQUFBwIBFhdodHRwczovL2Quc3ltY2IuY29tL2NwczAlBggrBgEF
# BQcCAjAZDBdodHRwczovL2Quc3ltY2IuY29tL3JwYTATBgNVHSUEDDAKBggrBgEF
# BQcDAzBXBggrBgEFBQcBAQRLMEkwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zdi5zeW1j
# ZC5jb20wJgYIKwYBBQUHMAKGGmh0dHA6Ly9zdi5zeW1jYi5jb20vc3YuY3J0MB8G
# A1UdIwQYMBaAFJY7U/B5M5evfYPvLivMyreGHnJmMB0GA1UdDgQWBBTT/6XRz3Tm
# jRZ6bHXd7S59sNJAMTANBgkqhkiG9w0BAQsFAAOCAQEAgyAFTjTll6aT238GJoxA
# 3Zx/jr4RBi8I3YUHub/BZq7xCmuhlgQMhVzAvgMre/gPFSl9H8ghT9/mA/JdbP4d
# JQmyWB26+gDsY7aHAGxMaJIgJW4VA19zFO5oHht7EA91mrvVyd6PMEQOAytgfasc
# W0Way3Wzno+z3IhW6M9jl0o/nY6btDbJlEbKYOLhq7S3vpAIM+3ogJnCrMX7upeN
# 50FdxEEsFwad94Vspw5Hnw72Mu/Kp+KIbwwUSmyLEJOKEEh/G06duHKCxuuZpDBH
# AYTMNRlKMZmBgP063Ey7mRTN2T+U9iawjY676dQTwh1ivupMuqKbHxbxVmjOpYGF
# TDCCBVkwggRBoAMCAQICED141/l2SWCyYX308B7KhiowDQYJKoZIhvcNAQELBQAw
# gcoxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5WZXJpU2lnbiwgSW5jLjEfMB0GA1UE
# CxMWVmVyaVNpZ24gVHJ1c3QgTmV0d29yazE6MDgGA1UECxMxKGMpIDIwMDYgVmVy
# aVNpZ24sIEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25seTFFMEMGA1UEAxM8
# VmVyaVNpZ24gQ2xhc3MgMyBQdWJsaWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1
# dGhvcml0eSAtIEc1MB4XDTEzMTIxMDAwMDAwMFoXDTIzMTIwOTIzNTk1OVowfzEL
# MAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYD
# VQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBD
# bGFzcyAzIFNIQTI1NiBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCXgx4AFq8ssdIIxNdok1FgHnH24ke021hNI2JqtL9aG1H3
# ow0Yd2i72DarLyFQ2p7z518nTgvCl8gJcJOp2lwNTqQNkaC07BTOkXJULs6j20Tp
# Uhs/QTzKSuSqwOg5q1PMIdDMz3+b5sLMWGqCFe49Ns8cxZcHJI7xe74xLT1u3LWZ
# Qp9LYZVfHHDuF33bi+VhiXjHaBuvEXgamK7EVUdT2bMy1qEORkDFl5KK0VOnmVuF
# NVfT6pNiYSAKxzB3JBFNYoO2untogjHuZcrf+dWNsjXcjCtvanJcYISc8gyUXsBW
# UgBIzNP4pX3eL9cT5DiohNVGuBOGwhud6lo43ZvbAgMBAAGjggGDMIIBfzAvBggr
# BgEFBQcBAQQjMCEwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wEgYD
# VR0TAQH/BAgwBgEB/wIBADBsBgNVHSAEZTBjMGEGC2CGSAGG+EUBBxcDMFIwJgYI
# KwYBBQUHAgEWGmh0dHA6Ly93d3cuc3ltYXV0aC5jb20vY3BzMCgGCCsGAQUFBwIC
# MBwaGmh0dHA6Ly93d3cuc3ltYXV0aC5jb20vcnBhMDAGA1UdHwQpMCcwJaAjoCGG
# H2h0dHA6Ly9zMS5zeW1jYi5jb20vcGNhMy1nNS5jcmwwHQYDVR0lBBYwFAYIKwYB
# BQUHAwIGCCsGAQUFBwMDMA4GA1UdDwEB/wQEAwIBBjApBgNVHREEIjAgpB4wHDEa
# MBgGA1UEAxMRU3ltYW50ZWNQS0ktMS01NjcwHQYDVR0OBBYEFJY7U/B5M5evfYPv
# LivMyreGHnJmMB8GA1UdIwQYMBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqG
# SIb3DQEBCwUAA4IBAQAThRoeaak396C9pK9+HWFT/p2MXgymdR54FyPd/ewaA1U5
# +3GVx2Vap44w0kRaYdtwb9ohBcIuc7pJ8dGT/l3JzV4D4ImeP3Qe1/c4i6nWz7s1
# LzNYqJJW0chNO4LmeYQW/CiwsUfzHaI+7ofZpn+kVqU/rYQuKd58vKiqoz0EAeq6
# k6IOUCIpF0yH5DoRX9akJYmbBWsvtMkBTCd7C6wZBSKgYBU/2sn7TUyP+3Jnd/0n
# lMe6NQ6ISf6N/SivShK9DbOXBd5EDBX6NisD3MFQAfGhEV0U5eK9J0tUviuEXg+m
# w3QFCu+Xw4kisR93873NQ9TxTKk/tYuEr2Ty0BQhMYIQXzCCEFsCAQEwgZMwfzEL
# MAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYD
# VQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMTAwLgYDVQQDEydTeW1hbnRlYyBD
# bGFzcyAzIFNIQTI1NiBDb2RlIFNpZ25pbmcgQ0ECEHi2zQF4Amo4kM9tycfQvbIw
# CQYFKw4DAhoFAKBwMBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEMBgor
# BgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3
# DQEJBDEWBBSMJUxEevTsMkbNDBrYiOGrUIMeMDANBgkqhkiG9w0BAQEFAASCAQCG
# yaum/gBnEs7EG8Jt3Y5TnO29jbO8PWq6NHC/4n6VwlP6VcAMZu9dCOKQo9S9Qqhb
# qBCC/XHSRxz+F16m+s59M1JNYxE1H84Nr9w7KD9G7FT49U8mFaf8/GfGmzxp8JQi
# h3qf96gzv2QefQ6Ypz801rF/clYF9wbidr6JMadNHi9blXElVwoMgzO5FIhpxi4v
# LOyztEQ9FojSkmcUs2uw9LIDhEI026PPZOZ3fkojsh5gQqtEeq3ppcdpflhyhNSr
# luNMy5j/ahvV39YiNzofUJ6ElxSXsVipeY4TQq9SQ9yKE4TvZmljoIxjEaCMhaVM
# mYijX9+blK42Q50Xyf83oYIOLjCCDioGCisGAQQBgjcDAwExgg4aMIIOFgYJKoZI
# hvcNAQcCoIIOBzCCDgMCAQMxCzAJBgUrDgMCGgUAMIG4BgsqhkiG9w0BCRABBKCB
# qASBpTCBogIBAQYCKQIwITAJBgUrDgMCGgUABBRsKezClwgTocGLm1foCu1xU1Q6
# UgIEMIT0FRgPMjAxNjA0MjYxNzU1MzRaMAMCATygWqRYMFYxCzAJBgNVBAYTAlVT
# MRUwEwYDVQQKEwxHZW9UcnVzdCBJbmMxMDAuBgNVBAMTJ0dlb1RydXN0IDIwNDgt
# Yml0IFRpbWVzdGFtcGluZyBTaWduZXIgM6CCCwgwggRtMIIDVaADAgECAhBVRcoC
# JGGQ2XnutA25/7wYMA0GCSqGSIb3DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYD
# VQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGlt
# ZSBTdGFtcGluZyBTZXJ2aWNlcyBDQSAtIEcyMB4XDTE1MDYxMTAwMDAwMFoXDTIw
# MTIyOTIzNTk1OVowVjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDEdlb1RydXN0IElu
# YzEwMC4GA1UEAxMnR2VvVHJ1c3QgMjA0OC1iaXQgVGltZXN0YW1waW5nIFNpZ25l
# ciAzMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxL+oD9FYlWLUPD+A
# V8IegIe0dse/5BpDELCzC68jtQKMuWNdOGceKkzEgeTBA4As44SadbGTaCchXS9U
# QOZ2cPwkMoux4djpv6PfC9Zw7BvSfU69LaaoetPWtZuxRAfgYzw0DvUyKsUKYeNL
# 3vKN4DMvEXuuWDW+TpCOwbjx/RUXJNfTw1trUfDI3kg/ESvJ8QuPBGhU2ZAt3Q/K
# IudEg8ZK9YPLLnPi0k9VB+KYscHKqWJFP15BO9/VDzXfjIDGHCyNENU1NpQ502WK
# 0KwzELU5y+WmmNwSUshNcK7v2zox52IAxSNxtrU5RFUUeUvnH6U5G07Td92bgP7o
# +KbJsQIDAQABo4IBLTCCASkwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5o
# dHRwOi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6
# Ly90cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwDAYDVR0TAQH/
# BAIwADA8BgNVHR8ENTAzMDGgL6AthitodHRwOi8vdHMtY3JsLndzLnN5bWFudGVj
# LmNvbS90c3MtY2EtZzIuY3JsMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1Ud
# DwEB/wQEAwIHgDAdBgNVHQ4EFgQUX7phh1B30O/JQOtgILN1hnNG2cIwHwYDVR0j
# BBgwFoAUX5r1blzMzHSa1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBABvB
# ZRgjVelI0yUv8ZbgxhZdy++S2qUKG2gUHgwiXiv2hq3hQOkgY/iC2rX+q/jVvAkx
# 8JjpgTF0P5OtjJhpThUd37BTQSkuasSJDam5SyD9ISrGuHrhBvz8hhDrk0EXvqAl
# UG8F/JyRqtvESANkfMLKsokFv3iP+S/OSeJexNwCkA3AF03yJ3ncsjJzaxHZgmzS
# pkxsdSLoQ9dRIB4CVNYTgYmTQyMR2rtT9nfidgBgyj1CUSAfbEuOvjgMQm90Xvch
# R/vQzZs3XsgRtfNQUmOpbdspHmrpaBe1xK6I0NBHB1J5ZgL14qy+fSyX3h3X/PJM
# wVEYVfGjJ1TpAaK4JOcwggKhMIICCqADAgECAgEAMA0GCSqGSIb3DQEBBAUAMIGL
# MQswCQYDVQQGEwJaQTEVMBMGA1UECBMMV2VzdGVybiBDYXBlMRQwEgYDVQQHEwtE
# dXJiYW52aWxsZTEPMA0GA1UEChMGVGhhd3RlMR0wGwYDVQQLExRUaGF3dGUgQ2Vy
# dGlmaWNhdGlvbjEfMB0GA1UEAxMWVGhhd3RlIFRpbWVzdGFtcGluZyBDQTAeFw05
# NzAxMDEwMDAwMDBaFw0yMDEyMzEyMzU5NTlaMIGLMQswCQYDVQQGEwJaQTEVMBMG
# A1UECBMMV2VzdGVybiBDYXBlMRQwEgYDVQQHEwtEdXJiYW52aWxsZTEPMA0GA1UE
# ChMGVGhhd3RlMR0wGwYDVQQLExRUaGF3dGUgQ2VydGlmaWNhdGlvbjEfMB0GA1UE
# AxMWVGhhd3RlIFRpbWVzdGFtcGluZyBDQTCBnzANBgkqhkiG9w0BAQEFAAOBjQAw
# gYkCgYEA1itYeGFFhlPqNHtRnO2w5i4YDv7gX6gn07TJ4HxZThYOc1RgwX/2ny7p
# OoUkFTzbRwRjw57ElBpa30x689lDHTwQenkl25D+8FHnMNZBAP2fKN95vpS7nbYU
# 4yOF16lB4EykebArGovy+DuKPkWscZIAtJBBmPtf7fq3Lor4iDcCAwEAAaMTMBEw
# DwYDVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQQFAAOBgQBn2+LC5oc9QIOGNzV9
# H86awwxmIKi6qgSJhsL1EAgNv8uiBYrQTTY+9NfvacZe5LCUb0q5595biLZ72+Mn
# 5XbD8DXBy7UnmzN53JCmAJ53+vzNJ5RCFpzTHGjsv1zd5al7EAoydFQTMYuFA4SR
# t1gBMBQ4ryjK/LFQGRkJrIlJ0zCCA+4wggNXoAMCAQICEH6T6/t8xk5Z6kuad9QG
# /DswDQYJKoZIhvcNAQEFBQAwgYsxCzAJBgNVBAYTAlpBMRUwEwYDVQQIEwxXZXN0
# ZXJuIENhcGUxFDASBgNVBAcTC0R1cmJhbnZpbGxlMQ8wDQYDVQQKEwZUaGF3dGUx
# HTAbBgNVBAsTFFRoYXd0ZSBDZXJ0aWZpY2F0aW9uMR8wHQYDVQQDExZUaGF3dGUg
# VGltZXN0YW1waW5nIENBMB4XDTEyMTIyMTAwMDAwMFoXDTIwMTIzMDIzNTk1OVow
# XjELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTAw
# LgYDVQQDEydTeW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIENBIC0gRzIw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCxrLNJVEuXHBIK2CV5kSJX
# Km/cuCbEQ3Nrwr8uUFr7FMJ2jkMBJUO0oeJF9Oi3e8N0zCLXtJQAAvdN7b+0t0Qk
# a81fRTvRRM5DEnMXgotptCvLmR6schsmTXEfsTHd+1FhAlOmqvVJLAV4RaUvic7n
# mef+jOJXPz3GktxK+Hsz5HkK+/B1iEGc/8UDUZmq12yfk2mHZSmDhcJgFMTIyTsU
# 2sCB8B8NdN6SIqvK9/t0fCfm90obf6fDni2uiuqm5qonFn1h95hxEbziUKFL5V36
# 5Q6nLJ+qZSDT2JboyHylTkhE/xniRAeSC9dohIBdanhkRc1gRn5UwRN8xXnxycFx
# AgMBAAGjgfowgfcwHQYDVR0OBBYEFF+a9W5czMx0mtTdfe8/2+xMgC7dMDIGCCsG
# AQUFBwEBBCYwJDAiBggrBgEFBQcwAYYWaHR0cDovL29jc3AudGhhd3RlLmNvbTAS
# BgNVHRMBAf8ECDAGAQH/AgEAMD8GA1UdHwQ4MDYwNKAyoDCGLmh0dHA6Ly9jcmwu
# dGhhd3RlLmNvbS9UaGF3dGVUaW1lc3RhbXBpbmdDQS5jcmwwEwYDVR0lBAwwCgYI
# KwYBBQUHAwgwDgYDVR0PAQH/BAQDAgEGMCgGA1UdEQQhMB+kHTAbMRkwFwYDVQQD
# ExBUaW1lU3RhbXAtMjA0OC0xMA0GCSqGSIb3DQEBBQUAA4GBAAMJm495739ZMKrv
# aLX64wkdu0+CBl03X6ZSnxaN6hySCURu9W3rWHww6PlpjSNzCxJvR6muORH4KrGb
# sBrDjutZlgCtzgxNstAxpghcKnr84nodV0yoZRjpeUBiJZZux8c3aoMhCI5B6t3Z
# Vz8dd0mHKhYGXqY4aiISo1EZg362MYICKDCCAiQCAQEwcjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMgIQVUXKAiRhkNl57rQN
# uf+8GDAJBgUrDgMCGgUAoIGMMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAc
# BgkqhkiG9w0BCQUxDxcNMTYwNDI2MTc1NTM0WjAjBgkqhkiG9w0BCQQxFgQUis3t
# LsutgiAPtNtYTotmvqivHtkwKwYLKoZIhvcNAQkQAgwxHDAaMBgwFgQUkSEJPJWS
# NujcWD4UasZZQx8KnOYwDQYJKoZIhvcNAQEBBQAEggEADuhLXXz/qMG2gkLQehG3
# EL/ieN67yHIEScwLFnDa8uyvQqmR7Sja58jrWDO023LyvPXyM9SSrvZDrLeNmFDZ
# KOXT4r05mCKUCu5XN178unkvdjfd0nLLFL7vTkGiTQt/v8J6vtuA/9YTy8uY7YZv
# g29wVuX9qZFrmUQoNoGi70x6zGno5Kj0gzM89K+j+61QGGKdE9OYanv//OqAO66N
# lZnR2auqNMdFjWymNUeCu775pRBWWzbBo44Jx5YvS1qTXQh0971+eTJkfLPW4BI+
# 0JjKNUH5CB85qTMbDK9++FH20GMXcu1SI0AninwDXALOI25mVOB2OK0YZemokh8A
# cA==
# SIG # End signature block
